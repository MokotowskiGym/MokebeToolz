===========
MokebeToolz
===========


.. image:: https://img.shields.io/pypi/v/mkbtoolz.svg
        :target: https://pypi.python.org/pypi/mkbtoolz

.. image:: https://img.shields.io/travis/MokotowskiGym/mkbtoolz.svg
        :target: https://travis-ci.com/MokotowskiGym/mkbtoolz

.. image:: https://readthedocs.org/projects/mkbtoolz/badge/?version=latest
        :target: https://mkbtoolz.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Mokebe nic nie musiał robić


* Free software: GNU General Public License v3
* Documentation: https://mkbtoolz.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
